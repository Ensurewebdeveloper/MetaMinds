
         document.addEventListener('DOMContentLoaded', function() {
            // Animate social icons on hover
            const socialIcons = document.querySelectorAll('.social-icon');
            socialIcons.forEach(icon => {
                icon.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-5px) rotate(5deg)';
                });
                icon.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(0) rotate(0)';
                });
            });
            
            // Animate footer links on load
            gsap.utils.toArray('.footer-link').forEach((link, i) => {
                gsap.from(link, {
                    scrollTrigger: {
                        trigger: link,
                        start: "top 90%",
                        toggleActions: "play none none none"
                    },
                    x: -20,
                    opacity: 0,
                    duration: 0.5,
                    delay: i * 0.1
                });
            });
        });
        // Header scroll effect
        const header = document.getElementById('mainHeader');
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                header.classList.add('header-scrolled');
            } else {
                header.classList.remove('header-scrolled');
            }
        });
        
        // Mobile menu toggle
        const hamburger = document.getElementById('hamburger');
        const mobileMenu = document.getElementById('mobileMenu');
        
        hamburger.addEventListener('click', function() {
            this.classList.toggle('open');
            mobileMenu.classList.toggle('open');
        });
        
        // Close mobile menu when clicking a link
        const mobileLinks = document.querySelectorAll('.mobile-menu .nav-link');
        mobileLinks.forEach(link => {
            link.addEventListener('click', function() {
                hamburger.classList.remove('open');
                mobileMenu.classList.remove('open');
            });
        });
        
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            });
        });
        
        // Add IDs to your sections for navigation
        document.querySelector('.features-grid').parentElement.id = 'features';
        document.querySelector('.chatbot-container').parentElement.id = 'chat';
        document.querySelector('.wallet-section').id = 'wallet';
        document.querySelector('.roadmap').id = 'roadmap';
    
        // Typewriter Effect
        document.addEventListener('DOMContentLoaded', function() {
            const typed = new Typed('#typewriter', {
                strings: ['Decentralized Future of AI'],
                typeSpeed: 50,
                showCursor: false
            });

            // Wallet connection simulation
            const connectButton = document.querySelector('.connect-button');
            connectButton.addEventListener('click', function() {
                this.classList.add('connected');
                this.textContent = '0x7f...3a4b Connected';
                
                // Simulate loading tokens
                setTimeout(() => {
                    document.querySelector('.token-list').style.opacity = '1';
                }, 500);
            });

            // Simple Three.js background
            const scene = new THREE.Scene();
            const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
            const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
            renderer.setSize(window.innerWidth, window.innerHeight);
            document.getElementById('webgl-background').appendChild(renderer.domElement);

            // Create neural network connections
            const points = [];
            const colors = [];
            
            for (let i = 0; i < 100; i++) {
                points.push(
                    Math.random() * 2 - 1,
                    Math.random() * 2 - 1,
                    Math.random() * 2 - 1
                );
                
                colors.push(
                    0.2, 0.6, 1,  // blue
                    0.9, 0.2, 1    // purple
                );
            }
            
            const geometry = new THREE.BufferGeometry();
            geometry.setAttribute('position', new THREE.Float32BufferAttribute(points, 3));
            geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
            
            const material = new THREE.LineBasicMaterial({ 
                vertexColors: true,
                transparent: true,
                opacity: 0.5
            });
            
            const lines = new THREE.LineSegments(geometry, material);
            scene.add(lines);
            
            camera.position.z = 2;
            
            // Animation loop
            function animate() {
                requestAnimationFrame(animate);
                
                lines.rotation.x += 0.001;
                lines.rotation.y += 0.002;
                
                renderer.render(scene, camera);
            }
            
            animate();
            
            // Handle window resize
            window.addEventListener('resize', function() {
                camera.aspect = window.innerWidth / window.innerHeight;
                camera.updateProjectionMatrix();
                renderer.setSize(window.innerWidth, window.innerHeight);
            });

            // GSAP animations for scroll
            gsap.registerPlugin(ScrollTrigger);
            
            gsap.utils.toArray('.feature-card').forEach((card, i) => {
                gsap.from(card, {
                    scrollTrigger: {
                        trigger: card,
                        start: "top 80%",
                        toggleActions: "play none none none"
                    },
                    y: 50,
                    opacity: 0,
                    duration: 0.8,
                    delay: i * 0.1
                });
            });
            
            gsap.utils.toArray('.timeline-node').forEach((node, i) => {
                gsap.from(node, {
                    scrollTrigger: {
                        trigger: node,
                        start: "top 80%",
                        toggleActions: "play none none none"
                    },
                    x: i % 2 === 0 ? -50 : 50,
                    opacity: 0,
                    duration: 0.8,
                    delay: i * 0.1
                });
            });
        });
    